Page({
  onGetToken() {
    // 线上必须是https。在开发环境中在项目设置里设置不效验域名
    wx.login({
      success: (res) => {
        wx.request({
          url: 'http://localhost:3000/v1/token',
          method: 'POST',
          data: {
            "account": res.code,
            "type": 100
          },
          success:(respose)=>{
            debugger
          }
        })
      }
    })


  }
})